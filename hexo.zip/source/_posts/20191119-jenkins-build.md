---
title: Jenkins-1、jenkins环境搭建  
date: 2019-11-19 00:00:01
tags: 
- jenkins  
- deploy  
categories: 
- Jenkins
---

# Jenkins环境搭建  

## 1、jdk安装  
### 1.1 安装jdk  
此步骤省略，参考这篇文章  

## 2、Jenkins安装  
以下是jenkins安装的完整步骤:  
### 2.1 下载jenkins  
下载jenkin命令:  

wget https://pkg.jenkins.io/redhat/jenkins-2.205-1.1.noarch.rpm 
  

### 2.2 安装jenkins  
安装执行：

rpm -ivh jenkins-2.83-1.1.noarch.rpm  



### 2.3 修改jenkins用户和端口  
修改用户和端口：  

vi /etc/sysconfig/jenkins
JENKINS_USER=root
JENKINS_PORT=8888  
 

### 2.4 启动服务:  
执行启动命令:  
systemctl start jenkins


本人第一次启动是失败的遇到如下问题：  

[root@localhost ~]# systemctl start jenkins
Job for jenkins.service failed because the control process exited with error code. See systemctl status jenkins.service and journalctl -xe for details.


按照提示输入查看问题,发现是jdk问题：    

[root@localhost bin]# systemctl status jenkins.service
Starting Jenkins bash: /software/jdk/jdk1.8.0_152/bin: 是一个目录

所以需要修改按如下修改一下  


vi /etc/init.d/jenkins

在最下面添加你的jdk位置即可  

candidates=
/etc/alternatives/java
/usr/lib/jvm/java-1.8.0/bin/java
/usr/lib/jvm/jre-1.8.0/bin/java
/usr/lib/jvm/java-1.7.0/bin/java
/usr/lib/jvm/jre-1.7.0/bin/java
/usr/bin/java
/software/jdk/jdk1.8.0_152/bin/java


重新执行如下命令:  


systemctl daemon-reload
systemctl start jenkins
 

然后就启动成功了

### 2.5 访问服务:  
地址：http:\\服务器ip:上面配置的port 都是你之前配置的,配置步骤就省略了    
http://10.170.198.239:8080/  
yonyou/yonyou@600588
![图p1](20191119-jenkins-build/1.png)
<center>**图p1**</center >
ok搭建完成。


### 2.6 maven插件安装和Git插件安装
在系统管理-->插件管理中安装插件
![图p2](20191119-jenkins-build/5.jpg)
<center>**图p2**</center >

