---
title: goroutine
date: 2020-12-04 00:00:01 
tags: 
- Go并发编程
categories: 
- Golang并发编程
---

## **前言**   

之前学JAVA并发编程的时候，了解到了cpu内存模型、JMM、竞态资源、同步关键字synchronized、可见性以及指令重排关键字volatile再到后面的AQS源码等等。可以说JAVA的并发编程体系是非常完善的，但据说golang是天生就具备并发性能的语言，今天就来好好学习一下golang并发编程中的第一个重要概念goroutine。

## **并发与并行**

相信学过并发编程的同学一定对这两个概念不陌生，我这里就只举两个非常简单形象的例子来描述一下：

**并发：假如你是一个渣男，某一天晚上你用微信轮流不停的和两个女朋友聊天**

**并行：你和你老弟都是好男人，某一天晚上你们都在用微信和自己女朋友聊天**

Java中通过Thread实现并发，GoLang中的并发则通过goroutine实现。goroutine类似于线程，属于用户态的线程，我们可以根据需要创建成千上万个goroutine并发工作。goroutine是由Golang的运行时调度完成的，而线程是由操作系统调度完成。

golang还提供channel在多个goroutine间进行通信。goroutine和channel是Go语言秉承的CSP(Communicating Sequential Process)并发模式的重要实现基础

## **goroutine**

在JAVA中要实现并发编程的时候，通常需要自己维护一个Threadpool，并且需要自己去包装一个又一个的任务(runnable or callable其实本质还是用户态Thread)往这个池子中丢任务，线程池根据自己的工作机制来运行这个任务或者阻塞这个任务又或者拒绝这个任务，今天我们不讨论JAVA线程池，有兴趣的朋友可以看我另外一篇文章，**[JAVA中线程池工作原理](https://www.baidu.com)**点这里查看。

`goroutine`的概念类似于线程，但 `goroutine`是由Go的运行时（runtime）调度和管理的。Go程序会智能地将 goroutine 中的任务合理地分配给每个CPU。Go语言之所以被称为现代化的编程语言，就是因为它在语言层面已经内置了调度和上下文切换的机制。

在Go语言编程中你不需要去自己写进程、线程、协程，你的技能包里只有一个技能 –`goroutine`，当你需要让某个任务并发执行的时候，你只需要把这个任务包装成一个函数，开启一个`goroutine`去执行这个函数就可以了，就是这么简单粗暴。

### use goroutine

Go语言中使用`goroutine`非常简单，只需要在调用函数的时候在前面加上`go`关键字，就可以为一个函数创建一个`goroutine`。一个`goroutine`必定对应一个函数，可以创建多个`goroutine`去执行相同的函数。

#### 启动单个goroutine

Golang中启动goroutine的方式非常简单，只需要在调用的函数（普通函数和匿名函数）前面加上一个`go`关键字。如下示例：

```go
func hello() {
	fmt.Println("Hello stephen!")
}
func main() {
	hello()
	fmt.Println("main stephen over!")
}
```

这个示例中hello函数和下面的语句是串行的，执行的结果是打印完`Hello stephen!`后打印`main stephen done!`。

下面我们在调用hello函数前面加上关键字`go`，也就是启动一个goroutine去执行hello这个函数。

```go
func main() {
	go hello() // 启动另外一个goroutine去执行hello函数
	fmt.Println("main stephen done!")
}
```

这一次的执行结果只打印了`main stephen done!`，并没有打印`Hello stephen!`。为什么呢？在程序启动时，Go程序就会为`main()`函数创建第一个默认的`goroutine`，这个goroutine。当main()函数返回的时候该`goroutine`就结束了，所有在`main()`函数中启动的`goroutine`会一同结束，`main`函数所在的`goroutine`就像是打着降龙十八掌的乔峰，乔峰运功十八条龙(sub goroutines)在空气里穿梭，乔峰收工，十八条龙在空气中消失。这样好理解了吧。所以我们要想办法让main函数等一等hello函数，java中我们可以通过Thread.sleep()或者while(true)，而golang这里最简单粗暴的方式就是`time.Sleep`了。

```go
func main() {
	go hello() // 启动另外一个goroutine去执行hello函数
	fmt.Println("main stephen done!")
	time.Sleep(time.Second)
}
```

执行上面的代码你会发现，这一次先打印`main stephen done!`，然后紧接着打印`Hello stephen !`。这里会先打印`main stephen done!`是因为我们在创建新的goroutine的时候需要花费一些时间，而此时main函数所在的`goroutine`是继续执行的。

#### 启动多个goroutine(引出WaitGroup)

了解到如何启动单个goroutine后，那么启动多个goroutine同理如下，同样我们需要main goroutine在一系列的sub goroutine执行完之前保持存活状态，这里就引入了一个新的概念WaitGroup，这个东西我在学习java并发编程的时也是有发现类似功能的组件的，比如AQS的直接产物CountDownLatch或者间接产物CyclicBarrier，原理也比较有趣，有兴趣了解其工作原理的**[戳这里](https://www.baidu.com)**。

```go
var wg sync.WaitGroup

func hello(i int) {
	defer wg.Done() // goroutine结束就登记-1
	fmt.Println("Hello stephen!", i)
}
func main() {
	for i := 0; i < 10; i++ {
		wg.Add(1) // 启动一个goroutine就登记+1
		go hello(i)
	}
	wg.Wait() // 等待所有登记的goroutine都结束
}
```

执行上述代码，你会发现执行的打印结果每一次都是不一样的，原因也很简单，因为后台的goroutine的调度是随机的~，好了今天我们初步的了解了goroutine的一些基本概念和基本用法，下一篇来详细讨论一下GMP调度模型，学习一下goroutine调度背后的故事。

![](20201204-goroutine/6.jpg)