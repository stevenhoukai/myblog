---
title: Golang练习二
date: 2020-11-28 00:00:01 
tags: 
- Golang习题
categories: 
- Golang
---

学习Golang的过程中，练习必不可少，俗话说的好 Talk is cheap,show me the code，学完Golang基本语法，是需要适当做一些练习加深理解的，虽然很很很简单！但是本人Java转go，语法还是要多熟悉，秉承多写一遍就多一次理解的原则，开始吧~

- #### **练习4**

  ```
//练习4
  //打印9*9乘法口诀表
  package main
  
  import "fmt"
  
  /*
   * 练习4 打印乘法乘法口诀表
   */
  
  func test4() {
  	for i := 1; i <= 9; i++ {
  		for j := 1; j <= 9; j++ {
  			if j <= i {
  				fmt.Printf("%v * %v = %v ", i, j, i*j)
  			}
  		}
  		fmt.Printf("\n")
  	}
  }
  
  func main() {
  	test4()
  }
  
  ```
  
- #### **练习5**

  ```
//练习5
  //编写代码统计出字符串中每一个单词出现的次数
  func test5() {
  	mymap := make(map[string]int)
  	str := "how do you do"
  	arr := strings.Split(str, " ")
  	for _, v := range arr {
  		value, ok := mymap[v]
  		if ok {
  			mymap[v] = value + 1
  		} else {
  			mymap[v] = 1
  		}
  	}
  	fmt.Println(mymap)
  }
  ```
  
- #### **练习6**

  ```
func calc(index string, a, b int) int {
  	ret := a + b
  	fmt.Println(index, a, b, ret)
  	return ret
  }
  
  func main() {
  	x := 1
  	y := 2
  	defer calc("AA", x, calc("A", x, y))
  	x = 10
  	defer calc("BB", x, calc("B", x, y))
  	y = 20
  }
  //思考下输出结果？提示一下:
  //defer注册要延迟执行的函数时该函数所有的参数都需要确定其值
  //defer入栈出栈？
  ```
  
- #### **练习7**

  ```
/*
  你有100枚金币，需要分配给以下几个人：Matthew,Sarah,Augustus,Heidi,Emilie,Peter,Giana,Adriano,Aaron,Elizabeth。
  分配规则如下：
  a. 名字中每包含1个'e'或'E'分1枚金币
  b. 名字中每包含1个'i'或'I'分2枚金币
  c. 名字中每包含1个'o'或'O'分3枚金币
  d: 名字中每包含1个'u'或'U'分4枚金币
  写一个程序，计算每个用户分到多少金币，以及最后剩余多少金币？
  程序结构如下，请实现 ‘dispatchCoin’ 函数
  */
  var (
  	coins = 100
  	users = []string{
  		"Matthew", "Sarah", "Augustus", "Heidi", "Emilie", "Peter", "Giana", "Adriano", "Aaron", "Elizabeth",
  	}
  	distribution = make(map[string]int, len(users))
  )
  
  func dispatchCoin() int {
  	for _, v := range users {
  		var count = 0
  		for _, val := range v {
  			switch val {
  			case 'e':
  				count++
  			case 'E':
  				count++
  			case 'i':
  				count = count + 2
  			case 'I':
  				count = count + 2
  			case 'o':
  				count = count + 3
  			case 'O':
  				count = count + 3
  			case 'u':
  				count = count + 4
  			case 'U':
  				count = count + 4
  			}
  		}
  		distribution[v] = count
  		coins = coins - count
  	}
  	fmt.Println(distribution)
  	return coins
  }
  
  func main() {
  	left := dispatchCoin()
  	fmt.Println("剩下：", left)
  }
  ```
  
  Talk is cheap,show me the code~
  
  ![](20201126-blbinarytree/1.jpeg)

