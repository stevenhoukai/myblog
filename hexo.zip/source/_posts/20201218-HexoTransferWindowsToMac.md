---
title: hexo迁移（Windows -> Mac）
date: 2020-12-18 00:00:01 
tags: 
- Hexo
categories: 
- Hexo
---

## Hexo迁移（Windows -> Mac）

最近因工作需要换了台mac，需要将windows上面的hexo全数转移至新机，记录一下整个过程。

### 1.找到自己Windows的hexo根目录

### 2.在 Mac 安装git和node.js

首先在自己电脑上装好node和git（首先确保brew安装好了） 

`brew install git`

`brew install node`

### 3.安装hexo

*用node.js来安装，这里可能会安装失败，我这里是切换npm源才成功*

`npm config set registry https://registry.npm.taobao.org`

`npm install -g hexo-cli` 

### **4.初始化hexo目录**

新建一个hexo目录，mkdir blog，cd blog

`hexo init`
在用`hexo s`

测试是否成功，打开`localhost:4000`查看本地 

### 5.生成SSH密钥，关联github

先查看本地的SSH key: `cd ~/.ssh`
(我是新买的mac，这一步需要直接先走安装）
$ssh-keygen -t rsa -C "youremail@example.com"  后面那个是注册邮箱

进入.ssh文件夹： `cd ~/.ssh`，然后打开里面的 id_rsa.pub文件，里面的内容就是 SSH key，复制全部内容；

网页打开 github 的设置：Settings -> SSH and GPG keys，点击绿色的按钮 New SSH key，然后在输入框中输入刚才复制的内容；

保存后，github 会向你的邮箱发送一个验证链接（记得要去登录邮箱验证，不然之后的 hexo d 部署会一直不成功的！）；

可以先测试一下是否成功：ssh git@github.com，
看到以下即成功：

> ```
> PTY allocation request failed on channel 0
> Hi gjincai! You've successfully authenticated, but GitHub does not provide shell access.
> Connection to github.com closed.
> ```

### 6.文件配置转移

windows 下的博客根目录 hexo，复制该目录下的：`_config.yml`, `scaffolds`, `source`, `themes`；
mac 下的博客根目录 hexo，把刚才复制的内容，直接覆盖替换相同的文件文件夹。

###  7.设置个人信息

`git config --global user.name "yourname"`

`git config --global user.email youremail@example.com`

到这就好了，和往常一样hexo g   hexo d(或者直接hexo g -d)发布文章吧！结果会提示ERROR Deployer not found: git

安装以下再尝试：`npm install hexo-deployer-git --save（若提示有关权限不足的，加sudo，反正我是遇到了）`

###  8.最重要！！！！！！！

以上是通常情况下的解决方案，本人遇到这个问题其实比较棘手并没有那么的顺利：本人旧机Window安装的node是v10.15.3，hexo版本是v3.9.0；要知道hexo最新版本已经是v5.2.0，跟旧版本相比有了很大的改动，比如主题安装，变化还是比较多的。所以最好是确定node版本在12或13或者以下版本，hexo版本最好也保持一致，否则会出现deploy d失败的情况，可以通过nvm安装多版本node解决即可

![](20201204-goroutine/6.jpg)