---
title: 总结一下
date: 2020-10-16 11:57:47
tags: 
- 总结 
categories: 
- 总结 
---
## 后面该写一些什么
之前很长一段时间没有更新，其实也不是因为懒，主要是有很多东西需要沉淀和研究，该写的东西应该是都有记录，陆续再慢慢放上来，最主要是这个hexo的格式实在是太难调整了，在这里就打打鸡血，博客是要继续写的，好记性不如烂笔头，后续我这列了一个提纲，一步一步来写出自己的理解：   


- 1、并发编程  
- 2、jvm  
- 3、redis  
- 4、mysql  
- 5、框架分析(spring、springmvc、springboot、springcloud)  
- 6、rabbitmq  
- 7、zookeeper  
- 8、jdk源码分析  
- 9、分布式相关

接下来就开始吧！
![图p1](20201016-summarytobacktowrite/timg.jpg)
