---
title: Git---删除本地和远程分支
date: 2019-11-25 00:00:01
tags: 
- git
categories: 
- Git  
---
## Git---删除本地和远程分支  


1.列出本地和远程分支：  
```
git branch -a
```

2.删除本地分支：  
```
git branch -D BranchName
```

其中-D也可以是--delete，如：  
```
git branch --delete BranchName
```

3.删除本地的远程分支：
```
git branch -r -D origin/BranchName
```

4.远程删除git服务器上的分支：
```
git push origin -d BranchName
```

其中-d也可以是--delete，如：
```
git push origin --delete BranchName
```

5.再使用命令查看本地和远程分支情况
```
git branch -a
```
