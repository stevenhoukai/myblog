---
title: 如何实现一个带括号的四则混合运算表达式求值
date: 2020-11-25 00:00:01 
tags: 
- 栈 
categories: 
- 数据结构与算法
---

本题其实相对比较简单，只要了解如何利用stack将中缀表达式转为后缀表达式(去括号的过程)，然后对后缀表达式进行求值即可！这里不对stack的结构和原理进行讲解，可自行查阅相关数据，也比较简单。

- ###### **代码**

  ```
  //实现 (1+2)*4*(5+1)/2+3 求值
  public class ComputerReview {
  	public static void main(String[] args){
  		Scanner sc = new Scanner(System.in);
  		String s = sc.nextLine();
  		//1去括号，中缀转后缀
  		ArrayList<String> backExpList = tansToBackExp(s);
  		//2后缀计算
  		int result = compute(backExpList);
  		System.out.println(result);
  	}
  ```

  ```
  //这一步就是利用stack的特性将中缀表达式转换为后缀表达式同时去除掉括号的过程
  //实现方式有很多种，这里只是我的思路
  private static ArrayList tansToBackExp(String s) {
  		ArrayList<String> al = new ArrayList();
  		Stack<String> stack = new Stack<>();
  		for(int i = 0 ; i < s.length() ; i++){
  			String c = s.charAt(i)+"";
  			if(c.matches("\\d")){
  				al.add(c);
  			}else {
  				if(c.equals("(")){
  					stack.push(c);
  				}else if(c.equals("+")||c.equals("-")){
  					while(!stack.isEmpty()){
  						if(stack.peek().equals("(")){
  							break;
  						}
  						al.add(stack.pop());
  					}
  					stack.push(c);
  				}else if(c.equals("*")||c.equals("/")){
  
  					while(!stack.isEmpty()){
  						if(stack.peek().equals(" (")||stack.peek().equals("+")||stack.peek().equals("-")){
  							break;
  						}
  						if(c.equals("*")||c.equals("/")){
  							al.add(stack.pop());
  						}
  					}
  					stack.push(c);
  				}else {
  					while(!stack.isEmpty()){
  						if(!stack.peek().equals("(")){
  							al.add(stack.pop());
  						}else{
  							//这一步很关键
  							stack.pop();
  							break;
  						}
  					}
  				}
  			}
  		}
  		while(!stack.isEmpty()){
  			al.add(stack.pop());
  		}
  		return al;
  	}
  ```

  ```
  //这一步相对来说就比较简单了，直接对转换后的后缀表达式求值，还是利用栈的特性
  //遍历后缀表达式，遇到数字就压栈处理，遇到表达式就出栈计算结果然后将结果再压栈，
  //最后栈中剩下的数字就是最终的结果
  private static Integer compute(ArrayList<String> al) {
  		Stack<String> stack = new Stack<String>();
  		for(int i = 0 ; i < al.size(); i++){
  			String s = al.get(i);
  			if(s.matches("\\d")){
  				stack.push(s);
  				continue;
  			}
  			String str2 = stack.pop();
  			String str1 = stack.pop();
  			if("+".equals(s)){
  				stack.push(Integer.parseInt(str1)+Integer.parseInt(str2)+"");
  			}else if("-".equals(s)){
  				stack.push(Integer.parseInt(str1)-Integer.parseInt(str2)+"");
  			}else if("*".equals(s)){
  				stack.push(Integer.parseInt(str1)*Integer.parseInt(str2)+"");
  			}else if("/".equals(s)){
  				stack.push(Integer.parseInt(str1)/Integer.parseInt(str2)+"");
  			}
  		}
  		return Integer.parseInt(stack.peek());
  	}
  
  	
  ```

- ###### **总结**

  栈是一个很重要的数据结构，FILO、LIFO的策略值得我们好好理解学习，jvm中的栈以及本地方法栈也都是采用了这样的数据结构

  ![](20201016-summarytobacktowrite/1.jpg)
  
  ![](20201125-selfcomputer/5.jpeg)