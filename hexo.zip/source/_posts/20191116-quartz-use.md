---
title: Quartz---2、项目Quartz定时任务使用  
date: 2019-11-15 00:00:01
tags: 
- springcloud
- springboot
- quartz
categories: 
- Quartz
---
# 界面说明
注意如果项目启动报错:
需要执行以下语句安装必须包
```
npm install --save react-cron-builder
```
项目目前只采用一个任务组：ICBC  

### 1、界面展示
![图p1](20191116-quartz-use/1.jpg)
<center>**图p1**</center >
后台任务管理界面在系统设置里面，界面上能监控任务的实时状态

# 功能说明
目前后台任务节点包含以下功能
### 1、查询全部任务

![图p3](20191116-quartz-use/3.jpg)
<center>**图p2**</center >  

### 2、查询运行中任务
可以查询正在处于运行的任务   

### 3、新建Simple任务
![图p3](20191116-quartz-use/2.jpg)
<center>**图p3**</center >  

### 4、新建Cron任务
同上，只是jobtime换成的Cron表达式,关于Cron表达式,可以参考上一篇
[Cron表达式介绍](https://stevenhoukai.github.io/2019/11/15/20191115-quartz/)! 

### 5、修改任务  
可以动态的修改任务的执行计划等

### 6、暂停任务  
可以停止正在运行中的任务

### 7、继续任务  
可以重启启动已经暂停的任务  

### 8、立即运行一次任务  
内存copy一份job进行独立运行

### 9、删除任务  
手动删除不需要的job



# 开发说明
目前整个台任务采取独立jar包的方式，支持集群部署(集群服务器时间必须保持一致)，随机负载均衡策略。  
开发具体的自定job如下图:

![图p4](20191116-quartz-use/5.jpg)
<center>**图p4**</center >

![图p5](20191116-quartz-use/4.jpg)
<center>**图p5**</center >

自定义job类按照如图方式必须继承QuartzJobBean,并且重写executeInternal方法，在方法中添加业务代码即可，注意自定义job类上的注解要保留，目前业务代码的事务还在测试中，非数据库交互定时任务可以正常使用



